(function($){
	/*常量定义*/
	/*雷的状态，初始态、已点击、已标记*/
	var MINE_STATUS = {MINE_NEW:0,MINE_OPENED:1,MINE_MARKED:2};
	/*数字颜色数组，根据不同的雷数取不同颜色，雷数-1即为数组下标*/
	var NUM_COLORS=["blue","green","red","darkblue","darkred","hotpink","purple","teal"];
	/*游戏状态：0游戏未开始，1游戏进行中，2游戏结束*/
	var GAME_STATUS = {GAME_NEW:0,GAME_START:1,GAME_OVER:2};

	/*选择游戏等级的事件处理函数*/
	function selectLevel(target,obj){
		var idx = obj.value;
		var levels = $.data(target,"winmine").options['levels'];
		if(idx==0){
			alert("未选择");
		}else if(idx==levels.length+1){
			alert("自定义");
		}else{
			resetGame(target,levels[idx-1]);
		}
	}

	/*以指定难度或者当前难度（没传level参数的话）重新开始游戏*/
	function reset(target,level){
		var curLevel = level;
		if(!curLevel){
			var gameStatus = $(target).data('gameStatus');
			if(!gameStatus) return;
			curLevel = gameStatus.curLevel;
		}
		resetGame(target,curLevel);
	}

	/*根据配置重新生成扫雷区，即回到游戏未开始状态（左键点击雷区开启任意一块时才视为开始，那时才开始计时）*/
	function resetGame(target,level){
		var gameStatus = {
			mines : null,
			mineLeft : level['count'],/*当前剩余未标记的雷的数量*/
			timeUsed : 0,/*已用时间*/
			gTimmer : null,/*游戏计时器*/
			status : GAME_STATUS.GAME_NEW,/*游戏状态，0未开始，1进行中，2结束*/
			curLevel : level,/*当前游戏级别信息*/
			lastX : null, /*上次触发鼠标事件时的x坐标*/
			lastY : null, /*上次触发鼠标事件时的y坐标*/
			lastLBtn : false,/*是否已按下鼠标左键（用于处理左右键事件）*/
			lastRBtn : false /*是否已按下鼠标右键（用于处理左右键事件）*/
		};
		$(target).find('.winmine-mines-table').children().remove();
		var mines = fillMines(level);
		gameStatus['mines'] = mines;
		/*将扫雷数据存入jquery对象*/
		$(target).data('gameStatus',gameStatus);
		drawPanes(target,mines);
		refreshStatus(target);
	}

	/*更新游戏状态显示*/
	function refreshStatus(target,flag){
		var gameStatus = $(target).data('gameStatus');
		if(flag) gameStatus.timeUsed ++;
		$(target).find('.winmine-control-countleft').html(gameStatus.mineLeft);
		$(target).find('.winmine-control-timeused').html(gameStatus.timeUsed>999?999:gameStatus.timeUsed);
	}

	/*根据level生成并填充包含雷的二维数组*/
	function fillMines(level){
		var m = [];
		var w = level['width'];
		var h = level['height'];
		var cnt = level['count'];
		/*开辟存储空间*/
		for(var i=0;i<h;i++){
			m.push([]);
			for(var j=0;j<w;j++){
				m[i].push({isMine:false,status:MINE_STATUS.MINE_NEW,minesAround:0});
			}
		}

		/*随机放雷*/
		while(cnt>0){
			var tmpx = rand(0,w-1);
			var tmpy = rand(0,h-1);
			if(m[tmpy][tmpx].isMine==false){
				m[tmpy][tmpx].isMine=true;
				cnt--;
			}else{
				/*如果随机出的位置已存在雷，则在从此位置继续往下的第一个空位置放雷。这样可以减少循环调用随机函数的次数，从而提高性能*/
				breakPoint:
				for(var i=tmpy;i<h;i++){
					for(var j=tmpx;j<w;j++){
						if(m[i][j].isMine==false){
							m[i][j].isMine=true;
							cnt--;
							break breakPoint;
						}
					}
				}
			}
		}

		/*计算每个单元格周围雷的数量*/
		for(var i=0;i<h;i++){
			for(var j=0;j<w;j++){
				m[i][j].minesAround = minesCountAroundCell(m,j,i);
			}
		}

		return m;
	}

	/*根据数组画出扫雷区域*/
	function drawPanes(target,m){
		var mineTable = $(target).find('.winmine-mines-table');
		for(var i=0;i<m.length;i++){
			var tr = $('<tr></tr>').addClass('winmine-mines-row');
			for(var j=0;j<m[i].length;j++){
				var td = $('<td>&nbsp;</td>')
				.addClass('winmine-mines-cell-normal')
				.attr('y',i)
				.attr('x',j)
				.bind('mousedown',function(event){
					/*todo: 处理鼠标按下事件，这里主要是要处理td按下时的界面效果*/
					btnMouseDown(this,target,event);
				})
				.bind('mouseup',function(event){
					/*todo：处理鼠标弹起事件，这里主要处理对雷的判断，以及级联展开等，扫雷的主要功能（左键点开，左右键一起点击等）都要在这里处理*/
					btnMouseUP(this,target,event);
				})
				.bind('mouseout',function(event){
					/*todo：这里主要处理鼠标按下之后未弹起之时移动鼠标到不同格的时候的切换效果*/
					btnMouseOut(this,target);
				})
				.bind('mouseover',function(event){
					/*todo：这里主要处理鼠标按下之后未弹起之时移动鼠标到不同格的时候的切换效果*/
					btnMouseOver(this,target);
				})
				.appendTo(tr);
			}
			tr.appendTo(mineTable);
		}
	}

	/*鼠标按键按下时*/
	function btnMouseDown(btnobj,target,event){
		var gameStatus = $(target).data('gameStatus');
		/*如果游戏已结束，则不处理本次事件*/
		if(gameStatus.status == GAME_STATUS.GAME_OVER) return;
		var mines = gameStatus.mines;
		var x = parseInt($(btnobj).attr('x'));
		var y = parseInt($(btnobj).attr('y'));
		gameStatus.lastX = x;
		gameStatus.lastY = y;
		if(event.which==1){
			gameStatus.lastLBtn = true;
		}else if(event.which==3){
			gameStatus.lastRBtn = true;
		}

		if(gameStatus.lastLBtn && gameStatus.lastRBtn){
			/*如果此次按下导致左右键同时被按下了，则按下所有周围的区域*/
			downAround(target,x,y,true);
		}else if(event.which==3){
			/*如果是按下右键，并且此时没有按下左键，则代表标记/取消标记雷*/
			markPane(btnobj,target,x,y);

			gameStatus.lastRBtn = false;
			gameStatus.lastX = null;
			gameStatus.lastY = null;

			/*检查是否已经获胜*/
			if(checkWin(target)){
				afterWin(target);
			}
		}else if(event.which==1){
			/*如果是按下左键，则仅改变其单元格显示样式，在键释放时才做进一步处理*/
			/*只有未标记和未开启的格才能按下*/
			if(mines[y][x].status == MINE_STATUS.MINE_NEW) $(btnobj).removeClass().addClass('winmine-mines-cell-opened');
		}
	}

	/*鼠标按键释放时*/
	function btnMouseUP(btnobj,target,event){
		var gameStatus = $(target).data('gameStatus');
		/*如果游戏已结束，则不处理本次事件*/
		if(gameStatus.status == GAME_STATUS.GAME_OVER) return;

		/*如果按键释放时没有任何键被标记为被按下，则代表这是左右键点击操作中松开的最后一个键，不需要处理*/
		if(!gameStatus.lastLBtn && !gameStatus.lastRBtn) return;

		var x = parseInt($(btnobj).attr('x'));
		var y = parseInt($(btnobj).attr('y'));
		var lastX = gameStatus.lastX;
		var lastY = gameStatus.lastY;
		var btn = event.which;
		var mines = gameStatus.mines;
		var h = mines.length , w = mines[0].length;

		/*如果释放鼠标按键时，左右键均已按下，则视为左右键一起点击的操作*/
		if(gameStatus.lastLBtn && gameStatus.lastRBtn){
			/*todo:处理自动展开的过程*/
			/*弹起周围单元格,不包括自身*/
			downAround(target,x,y,false,true);

			/*
				如果满足条件迭代并级联周围需要受影响的格（不包括已标记的和已打开的格）
				条件是：该单元格已打开（已显示数字），并且该单元格周围标记的雷的数量（>=0）大于或等于该单元格显示的数字（即周围存在的雷数）
			*/
			if(mines[y][x].status==MINE_STATUS.MINE_OPENED && marksCountAroundCell(mines,x,y) >= mines[y][x].minesAround){
				for(var m=(y-1<0?0:y-1);m<=(y>h-2?h-1:y+1);m++){
					for(var n=(x-1<0?0:x-1);n<=(x>w-2?w-1:x+1);n++){
						if(mines[m][n].status==MINE_STATUS.MINE_NEW) cascadeOpenPane(target,n,m);
					}
				}
			}

			/*将记录按键状态和坐标的变量清空*/
			gameStatus.lastLBtn = false;
			gameStatus.lastRBtn = false;
			gameStatus.lastX = null;
			gameStatus.lastY = null;
			/*检查是否已经获胜*/
			if(checkWin(target)){
				afterWin(target);
			}
		}else if(btn==1){
			/*如果释放的是鼠标左键,则代表要打开该格*/
			gameStatus.lastLBtn = false;
			gameStatus.lastRBtn = false;
			gameStatus.lastX = null;
			gameStatus.lastY = null;
			/*如果点击的单元格是被标记过的，则此单元格无法打开，直接return掉*/
			if(gameStatus.mines[y][x].status == MINE_STATUS.MINE_MARKED) return;

			/*如果此时游戏还未进入开始状态，则改变游戏状态为游戏进行中，并且开启计时器*/
			if(gameStatus.status == GAME_STATUS.GAME_NEW){
				gameStatus.status = GAME_STATUS.GAME_START;
				gameStatus.gTimmer = window.setInterval(function(){
					refreshStatus(target,true);
				},1000);
			}

			cascadeOpenPane(target,x,y);
			/*检查是否已经获胜*/
			if(checkWin(target)){
				afterWin(target);
			}
		}
	}

	/*鼠标移出方格时*/
	function btnMouseOut(btnobj,target){
		var mineTable = $(target).find('.winmine-mines-table');
		var x = parseInt($(btnobj).attr('x'));
		var y = parseInt($(btnobj).attr('y'));
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;
		var lastX = gameStatus.lastX;
		var lastY = gameStatus.lastY;
		/*如果游戏已结束，或者自上次鼠标弹起后未再按下鼠标键则无需处理*/
		if(lastX == null || lastY ==null || gameStatus.status == GAME_STATUS.GAME_OVER) return;

		/*如果上次mousedown事件时是同时按下左右键，则要把周围的未点击过的方格都取消掉按下状态*/
		if(gameStatus.lastLBtn && gameStatus.lastRBtn){
			downAround(target,x,y,false);
		}else{
			/*只有未点击过的方格才需要改变状态*/
			if(mines[y][x].status == MINE_STATUS.MINE_NEW){
				$(mineTable).children().children().eq(y).children().eq(x).removeClass().addClass('winmine-mines-cell-normal');
			}
		}
	}

	/*鼠标移上方格时*/
	function btnMouseOver(btnobj,target){
		var mineTable = $(target).find('.winmine-mines-table');
		var x = parseInt($(btnobj).attr('x'));
		var y = parseInt($(btnobj).attr('y'));
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;
		var lastX = gameStatus.lastX;
		var lastY = gameStatus.lastY;
		/*如果游戏已结束，或者自上次鼠标弹起后未再按下鼠标键,或者上次按下鼠标键时的坐标和当前坐标一致则无需处理*/
		if(lastX == null || lastY ==null || gameStatus.status == GAME_STATUS.GAME_OVER || (lastX == x && lastY == y)) return;

		/*如果上次mousedown事件时是同时按下左右键，则要把周围的未点击过的方格都加上按下状态*/
		if(gameStatus.lastLBtn && gameStatus.lastRBtn){
			downAround(target,x,y,true);
		}else{
			/*只有未点击过的方格才需要改变状态*/
			if(mines[y][x].status == MINE_STATUS.MINE_NEW){
				$(mineTable).children().children().eq(y).children().eq(x).removeClass().addClass('winmine-mines-cell-opened');
			}
		}
	}

	/*标记和取消标记，同时会更新雷数的显示*/
	function markPane(btnobj,target,x,y){
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;

		if(gameStatus.mines[y][x].status == MINE_STATUS.MINE_NEW){
			gameStatus.mines[y][x].status = MINE_STATUS.MINE_MARKED;
			$(btnobj).removeClass().addClass('winmine-mines-cell-marked');
			gameStatus.mineLeft--;
		}else if(gameStatus.mines[y][x].status == MINE_STATUS.MINE_MARKED){
			gameStatus.mines[y][x].status = MINE_STATUS.MINE_NEW;
			$(btnobj).removeClass().addClass('winmine-mines-cell-normal');
			gameStatus.mineLeft++;
		}
		refreshStatus(target,false);
	}

	/*
		检查游戏状态，根据扫雷的情况判断当前是否已经获胜
		获胜的算法：
		1.标记的数量和本难度下雷的数量相同，并且全都标记正确，判定获胜
		2.剩下未开启的单元格的数量+已标记的数量=本难度下雷的数量，
			并且已标记部分全部标记正确（前面的条件成立的话，标记不可能不正确），判定获胜
			即：若剩下未开启并且未标记的单元格全都是雷，则直接判定获胜
		3.标记的雷中有错的肯定不能获胜，即标记为雷实际不是雷的，不能获胜

	*/
	function checkWin(target){
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;
		var flagCount=0;
		var blankCount=0;
		var mineCount=gameStatus.curLevel.count;
		
		for(var i=0;i<mines.length;i++){
			for(var j=0;j<mines[i].length;j++){
				if(mines[i][j].status==MINE_STATUS.MINE_MARKED){
					if(mines[i][j].isMine==false) return false;
					flagCount++;
				}else if(mines[i][j].status==MINE_STATUS.MINE_NEW){
					blankCount++;
				}
			}
		}
		return (flagCount+blankCount==mineCount)||(flagCount==mineCount);
	}

	/*
		获胜之后自动完成未完成的操作（打开、标记等），并停止计时器、解除掉事件绑定，弹出提示框等
		在获胜之后才能调用，否则可能会出现一些莫名其妙的错误，因为此方法仅操作MINE_NEW状态的单元格
		作弊请使用cheat方法
	*/
	function afterWin(target){
		var mineTable = $(target).find('.winmine-mines-table');
		var gameStatus = $(target).data('gameStatus');
		alert('恭喜你获得了胜利！共用时：'+gameStatus.timeUsed+'秒');
		var mines = gameStatus.mines;
		for(var i=0;i<mines.length;i++){
			for(var j=0;j<mines[i].length;j++){
				var node = mines[i][j];
				if(node.status==MINE_STATUS.MINE_NEW){
					if(node.isMine){
						markPane($(mineTable).children().children().eq(i).children().eq(j),target,j,i);
					}else{
						cascadeOpenPane(target,j,i);
					}
				}
			}
		}
		gameStatus.status = GAME_STATUS.GAME_OVER;
		/*停掉计时器*/
		clearInterval(gameStatus.gTimmer);
		gameStatus.gTimmer=0;

		/*卸载事件监听*/
		$(target).find('td').unbind();
	}

	/*
		如果点开的单元格周围雷的个数为0（即单元格上无数字），则该单元格周围所有未标记和未打开的单元格都可直接打开
	*/
	function cascadeOpenPane(target,x,y){
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;
		var h = mines.length , w = mines[0].length;

		if(mines[y][x].status!=MINE_STATUS.MINE_MARKED) openPane(target,x,y);
		if(gameStatus.status==GAME_STATUS.GAME_OVER) return;
		if(mines[y][x].minesAround==0){
			for(var m=(y-1<0?0:y-1);m<=(y>h-2?h-1:y+1);m++){
				for(var n=(x-1<0?0:x-1);n<=(x>w-2?w-1:x+1);n++){
					if(mines[m][n].status==MINE_STATUS.MINE_NEW) cascadeOpenPane(target,n,m);
				}
			}
		}
	}
	
	/*打开一个单元格*/
	function openPane(target,x,y){
		var mineTable = $(target).find('.winmine-mines-table');
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;
		var tdobj=$(mineTable).children().children().eq(y).children().eq(x);

		if(mines[y][x].isMine==false){
			/*不是雷则点开它*/
			var cnt = mines[y][x].minesAround;
			tdobj.html(cnt==0?"&nbsp;":cnt).removeClass().addClass('winmine-mines-cell-opened');
			if(cnt>0) tdobj.css('color',NUM_COLORS[cnt-1]);

			mines[y][x].status=MINE_STATUS.MINE_OPENED;
			return cnt;
		}else{
			/*是雷的话直接GAME OVER,并且检查和打开所有区域，标记错的雷也要显示为对应的样式*/
			gameover(target,x,y);
			return -1;
		}
	}

	/*结束游戏*/
	function gameover(target,x,y){
		var mineTable = $(target).find('.winmine-mines-table');
		var gameStatus = $(target).data('gameStatus');
		var mines = gameStatus.mines;
		gameStatus.status=GAME_STATUS.GAME_OVER;

		/*停掉计时器*/
		clearInterval(gameStatus.gTimmer);
		gameStatus.gTimmer=0;

		/*打开所有格*/
		for(var i=0;i<mines.length;i++){
			for(var j=0;j<mines[i].length;j++){
				var cell = $(mineTable).children().children().eq(i).children().eq(j);
				/*解除事件绑定*/
				$(cell).unbind();

				/*爆炸的单元格的样式*/
				if(i==y&&j==x){
					$(cell).removeClass().addClass('winmine-mines-cell-bombed');
				}else{
					/*处理标记为雷的单元格的样式*/
					if(mines[i][j].status==MINE_STATUS.MINE_MARKED){
						/*如果标记错了，要改为标记错误的样式，否则不用管它*/
						if(mines[i][j].isMine!=true){
							$(cell).removeClass().addClass('winmine-mines-cell-wrong');
						}
					/*处理即未被标记也未被点开的单元格的样式*/
					}else if(mines[i][j].status!=MINE_STATUS.MINE_OPENED){
						if(mines[i][j].isMine){
							$(cell).removeClass().addClass('winmine-mines-cell-mine');
						}else{
							var cnt = mines[i][j].minesAround;
							$(cell).removeClass().addClass('winmine-mines-cell-opened').html(cnt==0?"&nbsp;":cnt);
							if(cnt>0) $(cell).css('color',NUM_COLORS[cnt-1]);
						}
					}
				}
			}
		}
	}

	/*改变周围格的样式，flag参数值：true为点下的样式，false或其他为弹起的样式,exclude_self:改变样式的范围是否不包含xy那一格*/
	function downAround(target,_x,_y,flag,exclude_self){
		var mineTable = $(target).find('.winmine-mines-table');
		var gameStatus = $(target).data('gameStatus');
		/*如果游戏已结束则无需处理*/
		if(!gameStatus || gameStatus.status == GAME_STATUS.GAME_OVER) return;
		var mines = gameStatus.mines;
		var h = mines.length , w = mines[0].length;
		var x = parseInt(_x) , y = parseInt(_y);
		for(var m=(y-1<0?0:y-1);m<=(y>h-2?h-1:y+1);m++){
			for(var n=(x-1<0?0:x-1);n<=(x>w-2?w-1:x+1);n++){
				if(mines[m][n].status != MINE_STATUS.MINE_NEW || (exclude_self==true && m==_y && n == _x)) continue ;
				$(mineTable).children().children().eq(m).children().eq(n).removeClass().addClass(flag==true?'winmine-mines-cell-opened':'winmine-mines-cell-normal');;
			}
		}
	}

	/*作弊模式，打开所有雷区*/
	function cheat(target){
		var mineTable = $(target).find('.winmine-mines-table');
		var gameStatus = $(target).data('gameStatus');
		if(!gameStatus) return;
		var mines = gameStatus.mines;
		$(mineTable).children().children().each(function(i,tr){
			$(tr).children('td').each(function(j,td){
				$(td).removeClass();
				if(mines[i][j].isMine==true){
					$(td).addClass('winmine-mines-cell-mine').html('&nbsp;');
				}else{
					var mCount = mines[i][j].minesAround;
					$(td).addClass('winmine-mines-cell-opened').html(mCount>0?mCount:'&nbsp;')
					if(mCount>0) $(td).css('color',NUM_COLORS[mCount - 1]);
				}
			});
		});
	}

	/*计算该格周围已标记多少个雷(除开本格外。当然，能调用此方法已经代表本格已被点开了)*/
	function marksCountAroundCell(mines,_x,_y){
		var cnt=0;
		var h = mines.length , w = mines[0].length;
		var x = parseInt(_x) , y = parseInt(_y);
		for(var m=(y-1<0?0:y-1);m<=(y>h-2?h-1:y+1);m++){
			for(var n=(x-1<0?0:x-1);n<=(x>w-2?w-1:x+1);n++){
				if(m==y&&n==x) continue;
				if(mines[m][n].status == MINE_STATUS.MINE_MARKED) cnt++;
			}
		}
		return cnt;
	}

	/*计算该格周围有多少个雷（除本格外，当然，调用此方法的场景是本格已经被点开了，所以本格肯定不是雷）*/
	function minesCountAroundCell(mines,_x,_y){
		var cnt=0;
		var h = mines.length , w = mines[0].length;
		var x = parseInt(_x) , y = parseInt(_y);
		for(var m=(y-1<0?0:y-1);m<=(y>h-2?h-1:y+1);m++){
			for(var n=(x-1<0?0:x-1);n<=(x>w-2?w-1:x+1);n++){
				if(m==y&&n==x) continue;
				if(mines[m][n].isMine == true) cnt++;
			}
		}
		return cnt;
	}

	/*随机数生成器，生成从min至max之间（包含min和max）的随机整数*/
	function rand(min, max){return Math.floor(Math.max(min, Math.random() * (max + 1)));}

	/*初始化方法，自动调用*/
	function init(target){
		var opts=$.data(target,"winmine").options;

		var levels = opts['levels'];
		var levelSelector = '<select class="winmine-control-selector"><option value="0">选择难度</option>';
		$.each(opts['levels'],function(index,item){
			levelSelector+='<option value="'+(index+1)+'">'+item['name']+'</option>';
		});
		levelSelector+='<option value="'+(levels.length+1)+'">自定义难度</option></select>';

		$('<table class="winmine-control-panel">'+
			'<tr><td class="winmine-control-title">'+opts['title']+'</td></tr>'+
			'<tr>'+
				'<td class="winmine-control-difficulty">'+
					'选择难度:'+levelSelector+
					'<input type="button" class="winmine-control-resetor" value="重新开始"/>'+
				'</td>'+
			'</tr>'+
			'<tr class="winmine-control-statusbar">'+
				'<td>'+
					'剩余雷数:<span class="winmine-control-countleft winmine-control-monitor">0</span>'+
					'所用时间:<span class="winmine-control-timeused winmine-control-monitor">0</span>'+
				'</td>'+
			'</tr>'+
		'</table>').appendTo(target);

		$(target).find('.winmine-control-selector').bind('change',function(){selectLevel(target,this);});
		$(target).find('.winmine-control-resetor').bind('click',function(){reset(target);});	
		
		$('<table class="winmine-mines-table" border="1" cellspacing="0" cellpadding="0"/>').appendTo(target);

		$(document).bind("contextmenu",function(){return false;});  
		$(document).bind("selectstart",function(){return false;});  
	}

	/*jquery插件代码*/
	$.fn.winmine = function(options, param){
		if (typeof options == 'string'){
			return $.fn.winmine.methods[options](this, param);
		}
		
		options = options || {};
		return this.each(function(){
			if (!$.data(this, 'winmine')){
				$.data(this, 'winmine', {
					options: $.extend({}, $.fn.winmine.defaults, options)
				});
				init(this);
			}
		});
	};

	/*jquery插件提供的方法代码*/
	$.fn.winmine.methods = {
		reset:function(jq,options){
			return jq.each(function(){
				reset(this, $.extend({}, $.fn.winmine.defaults, options||{}));
			});
		},
		resetGame:function(jq,options){
			return jq.each(function(){
				reset(this, $.extend({}, $.fn.winmine.defaults, options||{}));
			});
		},
		cheat:function(jq,options){
			return jq.each(function(){
				cheat(this);
			});
		}
	};

	/*jquery插件的默认值代码*/
	$.fn.winmine.defaults = {
		width:9,
		height:9,
		num:10,
		title:'提示：规则同windows扫雷',
		levels:[
			{name:'初级(9x9,10个雷)',width:9,height:9,count:10},
			{name:'中级(16x16,40个雷)',width:16,height:16,count:40},
			{name:'高级(30x20,99个雷)',width:30,height:20,count:99}
		]
	};
})(jQuery);
